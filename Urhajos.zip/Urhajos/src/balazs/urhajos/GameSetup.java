package balazs.urhajos;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.Random;

public class GameSetup {//Engine

    private GamingPane myView;//Pane
    private Scene myScene;

    private Timeline boardTimeline;

    private IntegerProperty score = new SimpleIntegerProperty(0);

    private Ship ship = new Ship();
    private Planet planet = new Planet(FilePaths.MARS, Constants.PLANET_LARGE_HEIGHT,
            Constants.PLANET_LARGE_HEIGHT);
    private ArrayList<Planet> planets = new ArrayList<>();
    private ArrayList<Missile> missiles = new ArrayList<>();

    //hogy ne kelljen keresés közben elemeket elvenni vagy hozzáadni,
    //a létrejövő, vagy a megsemmisített és törlendő objektumokat egy
    //külön listában tárolom.
    public ArrayList<Item> objectsToDelete = new ArrayList<>();

    public GameSetup() {
        myView = new GamingPane();
        myScene = new Scene(myView, Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT);
        setPane(myView);
        setControlKeys();
        planet.setX(50);
        planet.setY(50);
        myView.getChildren().add(ship);
        addPlanets();
        for(Planet p : planets){
            myView.getChildren().add(p);
        }
        initTimelines();
    }

    private void addPlanets() {
        int i = 0;
        Random rand = new Random();
        boolean placeReserved = false;

        while(i<3){

            int x = rand.nextInt(500) + 50;
            int y = rand.nextInt(500) + 50;
            int type = rand.nextInt(10);

            for(Planet p : planets){
                if(Math.abs(x - p.getX()) < Constants.PLANET_LARGE_HEIGHT ||
                        Math.abs(y - p.getY()) < Constants.PLANET_LARGE_HEIGHT){
                    placeReserved = true;
                }
            }

            if(!placeReserved){
                String spriteName = FilePaths.MARS;
                switch (i){
                    case 0:
                        spriteName = FilePaths.ASTEROID; break;
                    case 1:
                        spriteName = FilePaths.JUPITER; break;
                    case 2:
                        spriteName = FilePaths.MARS; break;
                    case 3:
                        spriteName = FilePaths.MERCURY; break;
                    case 4:
                        spriteName = FilePaths.NEPTUNE; break;
                    case 5:
                        spriteName = FilePaths.PLUTO; break;
                    case 6:
                        spriteName = FilePaths.SATURN; break;
                    case 7:
                        spriteName = FilePaths.SUN; break;
                    case 8:
                        spriteName = FilePaths.URANUS; break;
                    case 9:
                        spriteName = FilePaths.VENUS; break;
                }
                planet = new Planet(spriteName, Constants.PLANET_LARGE_HEIGHT,
                        Constants.PLANET_LARGE_HEIGHT);
                planet.setX(x);
                planet.setY(y);
                planets.add(planet);
                i++;
            }
            placeReserved = false;


        }

    }

    private void setPane(GamingPane inputView) {
        this.myView = inputView;
        myView.bindActualScore(score);
        myView.setSetup(this);
        myScene.setRoot(myView);
    }

    private void setControlKeys() {
        myScene.setOnKeyPressed(e -> {
            try {
                switch (e.getCode()) {
                    case LEFT:
                    case A:
                        ship.makeMovement(Constants.Directions.LEFT); break;
                    case RIGHT:
                    case D:
                        ship.makeMovement(Constants.Directions.RIGHT); break;
                    case UP:
                    case W:
                        ship.makeMovement(Constants.Directions.THRUST); break;
                    case SPACE:
                        ship.shoot(); break;
                    case ESCAPE:
                        pause(); break;
                }
            } catch (NullPointerException ex) {
                System.err.println("Ship does not exist!");
            }
        });

        myScene.setOnKeyReleased(e -> {
            try {
                switch (e.getCode()) {
                    case LEFT:
                    case A:
                        ship.stopMovement(Constants.Directions.LEFT); break;
                    case RIGHT:
                    case D:
                        ship.stopMovement(Constants.Directions.RIGHT); break;
                    case UP:
                    case W:
                        ship.stopMovement(Constants.Directions.THRUST); break;
                }
            } catch (NullPointerException ex) {
                System.err.println("Player does not exist.");
            }
        });
    }

    private void pause() {
        boardTimeline.pause();

        Label pauseLabel = new Label("PAUSED");
        pauseLabel.setFont(Font.loadFont(ClassLoader.getSystemResource(FilePaths.FONT).toExternalForm(),
                14));
        pauseLabel.setMinSize(Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT);
        pauseLabel.setAlignment(Pos.CENTER);
        pauseLabel.setTranslateY(-2);
        pauseLabel.setTextAlignment(TextAlignment.CENTER);
        pauseLabel.setTextFill(Color.WHITE);

        Rectangle background = new Rectangle(Constants.WINDOW_WIDTH, 30,
                new Color(0, 0, 0, 0.6));
        background.setX(0);
        background.setY((Constants.WINDOW_HEIGHT / 2) - 12);

        myView.getChildren().addAll(background, pauseLabel);

        background.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case SPACE:
                    myView.getChildren().removeAll(background, pauseLabel);
                    play(); break;
                case ESCAPE:
                    Platform.exit(); break;
            }
        });
        background.requestFocus();
    }

    private void play() {
        boardTimeline.play();
    }

    private void initTimelines(){

        planets.add(planet);

        boardTimeline = new Timeline(new KeyFrame(Duration.millis(Constants.CLOCK_LENGTH), e -> {
            for(Missile missile: missiles){
                missile.actionAtClock();

                if(missile.getY() < 0 || missile.getY() > Constants.WINDOW_HEIGHT ||
                missile.getX() < 0 || missile.getX() > Constants.WINDOW_WIDTH){
                    objectsToDelete.add(missile);
                }
                for(Planet planet: planets){
                    if(missile.intersects(planet.getX(), planet.getY(),
                            planet.getWidth(), planet.getHeight())){
                        planet.destroyItem();
                        missile.destroyItem();
                        objectsToDelete.add(planet);
                        objectsToDelete.add(missile);
                        score.setValue(score.getValue() + 1);
                    }
                    if(ship.intersects(planet.getX(), planet.getY(),
                            planet.getWidth(), planet.getHeight())){
                        finishGame();
                    }
                }
            }

            for(Planet planet: planets){
                if(ship.intersects(planet.getX(), planet.getY(),
                        planet.getWidth(), planet.getHeight())){
                    finishGame();
                }
            }

            for(Item item: objectsToDelete){
                //mindegy hogy missile vagy planet, ha nem abból
                //távolítom el, amiben van, akkor nincs semmi
                missiles.remove(item);
                planets.remove(item);
            }
            objectsToDelete.clear();

            ship.actionAtClock();

            if(ship.getNumOfLivesIP() < 1){
                finishGame();
            }

        }));

        boardTimeline.setCycleCount(Timeline.INDEFINITE);
        boardTimeline.play();

    }

    public void finishGame() {
        boardTimeline.stop();
        Label gameOverLabel = new Label("GAME OVER, PRESS N FOR NEW GAME");
        gameOverLabel.setFont(Font.loadFont(ClassLoader.getSystemResource(FilePaths.FONT).toExternalForm(),
                10));
        gameOverLabel.setMinSize(Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT);
        gameOverLabel.setAlignment(Pos.CENTER);
        gameOverLabel.setTranslateY(-2);
        gameOverLabel.setTextAlignment(TextAlignment.CENTER);
        gameOverLabel.setTextFill(Color.WHITE);


        Rectangle background = new Rectangle(Constants.WINDOW_WIDTH, 30,
                new Color(0, 0, 0, 0.6));
        background.setX(0);
        background.setY((Constants.WINDOW_HEIGHT / 2) - 12);


        myView.getChildren().addAll(background, gameOverLabel);
        //restart, N-et nyom
        background.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case N:
                    newGame(); break;
                case ESCAPE:
                    Platform.exit(); break;
            }
        });
        background.requestFocus();

    }

    private void newGame() {

        planets.clear();
        missiles.clear();
        objectsToDelete.clear();
        setPane(myView);
        setControlKeys();



        ship = new Ship();

        setPane(new GamingPane());

        planet = new Planet(FilePaths.MARS, Constants.PLANET_LARGE_HEIGHT,
                Constants.PLANET_LARGE_HEIGHT);

        myView.getChildren().add(ship);

        addPlanets();
        for(Planet p : planets){
            myView.getChildren().add(p);
        }

        score.set(0);
        initTimelines();
        play();

    }


    public void addMissile(Missile missile) {
        missiles.add(missile);
        myView.getChildren().add(missile);
    }

    public GamingPane getMyView() {
        return myView;
    }

    public void setMyView(GamingPane myView) {
        this.myView = myView;
    }

    public Scene getMyScene() {
        return myScene;
    }

    public void setMyScene(Scene myScene) {
        this.myScene = myScene;
    }
}
