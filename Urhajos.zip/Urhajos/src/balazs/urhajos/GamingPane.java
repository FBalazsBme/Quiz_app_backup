package balazs.urhajos;

import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class GamingPane extends Pane {

    private GameSetup setup;

    private Label actualScore;
    private Label numOfLives;


    public GamingPane() {

        this.setBackground(new Background(new BackgroundFill(Color.rgb(8, 8, 8), null, null)));

        actualScore = new Label();
        actualScore.setMinWidth(Constants.WINDOW_WIDTH);
        actualScore.setFont(Font.loadFont(ClassLoader.getSystemResource(FilePaths.FONT).toExternalForm(),
                14));
        actualScore.setTextFill(Color.WHITE);
        actualScore.setAlignment(Pos.TOP_RIGHT);
        actualScore.setTextAlignment(TextAlignment.RIGHT);
        actualScore.setTranslateY(Constants.SCORE_SIZE + 2);

        numOfLives = new Label();
        numOfLives.setMinWidth(Constants.WINDOW_WIDTH);
        numOfLives.setFont(Font.loadFont(ClassLoader.getSystemResource(FilePaths.FONT).toExternalForm(),
                14));
        numOfLives.setTextFill(Color.WHITE);
        numOfLives.setAlignment(Pos.TOP_RIGHT);
        numOfLives.setTextAlignment(TextAlignment.RIGHT);
        numOfLives.setTranslateY(Constants.SCORE_SIZE + 2);

        this.getChildren().add(actualScore);
    }

    public void bindActualScore (ReadOnlyIntegerProperty score){
        actualScore.textProperty().bind(score.asString());
    }

    public void bindNumOfLives (ReadOnlyIntegerProperty lives){
        numOfLives.textProperty().bind(lives.asString());
    }

    public GameSetup getSetup() {
        return setup;
    }

    public void setSetup(GameSetup setup) {
        this.setup = setup;
    }

}
