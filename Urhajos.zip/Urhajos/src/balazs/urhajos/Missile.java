package balazs.urhajos;

public class Missile extends Item {

    protected double movePerClockX = 0;
    protected double movePerClockY = 0;



    public Missile(double startX, double startY, double ratioXperY, boolean isAnglePositive){
        super(FilePaths.PROJECTILE, Constants.MISSILE_HEIGHT, Constants.MISSILE_WIDTH);
        setX(startX);
        setY(startY);
        setMovesWithRatio(ratioXperY, isAnglePositive);
    }

    private void setMovesWithRatio(double ratioXperY, boolean isAnglePositive){
        double radians = Math.atan(ratioXperY);
        this.movePerClockY = isAnglePositive ? Math.sin(radians) * Constants.MISSILE_SPEED :
                Math.sin(radians) * Constants.MISSILE_SPEED * -1;
        this.movePerClockX = isAnglePositive ? Math.cos(radians) * Constants.MISSILE_SPEED :
                Math.cos(radians) * Constants.MISSILE_SPEED * -1;
    }

    @Override
    public void destroyItem() {
        super.setExists(false);
        super.setOpacity(0.25);
    }

    @Override
    public void actionAtClock() {
        movementControl();
    }

    private void movementControl() {
        if (getMovePerClockX() < 0) {
            if (getX() >= getMovePerClockX()) setX(getX() + getMovePerClockX());
            else {
                setMovePerClockX(0);
                setX(0);//pálya bal szélét érte el, stop
            }
        }else if (getMovePerClockX() > 0) {
            if (getX() < (Constants.WINDOW_WIDTH - width - getMovePerClockX()))
                setX(getX() + getMovePerClockX());
            else {
                setX(Constants.WINDOW_WIDTH - width - getMovePerClockX());
                setMovePerClockX(0);
            }
        }
        if (getMovePerClockY() < 0) {
            if (getY() >= (getMovePerClockY() + height)) setY(getY() + getMovePerClockY());
            else {
                setMovePerClockY(0);
                setY(height);
            }
        } else if (getMovePerClockY() > 0) {
            if (getY() < (Constants.WINDOW_HEIGHT - height - getMovePerClockY()))
                setY(getY() + getMovePerClockY());
            else {
                setY(Constants.WINDOW_HEIGHT - height - getMovePerClockY());
                setMovePerClockY(0);
            }
        }
    }

    public double getMovePerClockX() {
        return movePerClockX;
    }

    public void setMovePerClockX(double movePerClockX) {
        this.movePerClockX = movePerClockX;
    }

    public double getMovePerClockY() {
        return movePerClockY;
    }

    public void setMovePerClockY(double movePerClockY) {
        this.movePerClockY = movePerClockY;
    }
}
