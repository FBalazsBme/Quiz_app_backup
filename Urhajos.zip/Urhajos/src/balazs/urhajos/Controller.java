package balazs.urhajos;

public class Controller {
}
