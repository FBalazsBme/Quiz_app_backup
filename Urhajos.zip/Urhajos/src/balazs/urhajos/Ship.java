package balazs.urhajos;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.image.Image;

public class Ship extends Item {

    private int maxLives = 4;

    private IntegerProperty numOfLivesIP = new SimpleIntegerProperty(maxLives);

    private static Image spaceShipBase = new Image(FilePaths.SPACESHIP_BASE,
            Constants.PLAYER_WIDTH, Constants.PLAYER_HEIGHT, false, false);

    private static Image spaceShipDest1 = new Image(FilePaths.SPACESHIP_DES1,
            Constants.PLAYER_WIDTH, Constants.PLAYER_HEIGHT, false, false);

    private static Image spaceShipDest2 = new Image(FilePaths.SPACESHIP_DES2,
            Constants.PLAYER_WIDTH, Constants.PLAYER_HEIGHT, false, false);

    private static Image spaceShipPropel = new Image(FilePaths.SPACESHIP_THRUST,
            Constants.PLAYER_WIDTH, Constants.PLAYER_HEIGHT, false, false);

    protected double clockLength = 10.0;
    //clock length in ms, 1/clockLength = clockspeed
    private double movePerClockX = 0;
    private double movePerClockY = 0;
    private double rotatePerClock = 2.0;
    private double axisAngle = 0;

    private boolean setThrust = false;
    private boolean turnLeft = false;
    private boolean turnRight = false;

    public Ship(){
        this(FilePaths.SPACESHIP_BASE, Constants.PLAYER_WIDTH,
                Constants.PLAYER_HEIGHT, Constants.PLAYER_MAX_LIVES);
        setInitialPosition();
    }

    public Ship(String spriteName, double height, double width, int maxLives) {
        super(spriteName, height, width);
        this.maxLives = maxLives;
        numOfLivesIP.set(maxLives);
    }

    @Override
    public void destroyItem() {

    }

    @Override
    public void actionAtClock() {
        steeringControl();
        movementControl();
        if(setThrust){
            setImage(spaceShipPropel);
        } else {
            setImage(spaceShipBase);
        }
    }

    private void setInitialPosition() {
        setX((Constants.WINDOW_WIDTH - Constants.PLAYER_WIDTH)/2);
        setY((Constants.WINDOW_HEIGHT - Constants.PLAYER_HEIGHT)/2);
        setRotate(axisAngle);
    }

    public void makeMovement(Constants.Directions dir) {
        switch (dir) {
            case THRUST:
                setThrust = true; break;
            case LEFT:
                turnRight = true; break;
            case RIGHT:
                turnLeft = true; break;
        }
    }

    public void stopMovement(Constants.Directions dir) {
        switch (dir) {
            case THRUST:
                setThrust = false; break;
            case LEFT:
                turnRight = false; break;
            case RIGHT:
                turnLeft = false; break;
        }
    }

    public void shoot() {
        double normAngle = normalizeAngle(axisAngle);
        double radians;
        radians = Math.tan(Math.toRadians(normAngle));
        boolean anglePosSign = true;

        if(normAngle < -90 || normAngle > 90){
            anglePosSign = false;
        }
        ((GamingPane)getParent()).getSetup().addMissile(
                new Missile(
                        getMiddleCoordinateX() - (Constants.MISSILE_WIDTH / 2),
                        getMiddleCoordinateY() - Constants.MISSILE_HEIGHT,
                        radians,
                        anglePosSign
                )
        );
    }

    private double normalizeAngle(double angle)
    {
        double newAngle = angle;
        while (newAngle <= -180) newAngle += 360;
        while (newAngle > 180) newAngle -= 360;
        return newAngle;
    }
    
    public void steeringControl() {
        if((turnLeft == true || turnRight == true) && turnRight != turnLeft){
            if(turnLeft){
                axisAngle = getRotate() + rotatePerClock;
                setRotate(axisAngle);
            }
            if(turnRight){
                axisAngle = getRotate() - rotatePerClock;
                setRotate(axisAngle);
            }
        }
        if(setThrust){
            increaseMovePerClockX(
                    Math.cos(Math.toRadians(axisAngle)) * Constants.SHIP_THRUST);
            increaseMovePerClockY(
                    Math.sin(Math.toRadians(axisAngle)) * Constants.SHIP_THRUST);
        }
    }

    public void movementControl(){
        System.out.println(("X:" + getMovePerClockX()));
        System.out.println("Y:" + getMovePerClockY());
        if (getMovePerClockX() < 0) {
            if (getX() >= getMovePerClockX()) setX(getX() + getMovePerClockX());
            else {
                setMovePerClockX(0);
                setX(0);//pálya bal szélét érte el, stop
            }
        }else if (getMovePerClockX() > 0) {
            if (getX() < (Constants.WINDOW_WIDTH - width - getMovePerClockX()))
                setX(getX() + getMovePerClockX());
            else {
                setX(Constants.WINDOW_WIDTH - width - getMovePerClockX());
                setMovePerClockX(0);
            }
        }
        if (getMovePerClockY() < 0) {
            if (getY() >= (getMovePerClockY() + height)) setY(getY() + getMovePerClockY());
            else {
                setMovePerClockY(0);
                setY(height);
            }
        } else if (getMovePerClockY() > 0) {
            if (getY() < (Constants.WINDOW_HEIGHT - height - getMovePerClockY()))
                setY(getY() + getMovePerClockY());
            else {
                setY(Constants.WINDOW_HEIGHT - height - getMovePerClockY());
                setMovePerClockY(0);
            }
        }
    }

    public double getMovePerClockX() {
        return movePerClockX;
    }

    public void setMovePerClockX(double movePerClockX) {
        this.movePerClockX = movePerClockX;
    }

    public void increaseMovePerClockX(double addMove){
        setMovePerClockX(getMovePerClockX() + addMove);
    }

    public double getMovePerClockY() {
        return movePerClockY;
    }

    public void setMovePerClockY(double movePerClockY) {
        this.movePerClockY = movePerClockY;
    }

    public void increaseMovePerClockY(double addMove){
        setMovePerClockY(getMovePerClockY() + addMove);
    }

    public int getMaxLives() {
        return maxLives;
    }

    public void setMaxLives(int maxLives) {
        this.maxLives = maxLives;
    }

    public int getNumOfLivesIP() {
        return numOfLivesIP.get();
    }

    public IntegerProperty numOfLivesIPProperty() {
        return numOfLivesIP;
    }

    public void setNumOfLivesIP(int numOfLivesIP) {
        this.numOfLivesIP.set(numOfLivesIP);
    }

    public void decreaseLives(){
        numOfLivesIP.set(numOfLivesIP.get() - 1);
    }
}
